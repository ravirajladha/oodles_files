-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 29, 2022 at 06:01 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hellowcart2`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `sub_type` varchar(200) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id`, `type`, `name`, `email`, `phone`, `password`, `status`, `created_at`, `sub_type`, `vendor_id`) VALUES
(1, 'admin', 'Admin', 'admin@hellowcart.com', '', '$2y$10$Eg18EbyMVKsuBFTor0neuOsxkWbJsgLku/Z.qq1DMOyoDjqf9svyy', '0', '2022-04-06 16:46:11', NULL, NULL),
(2, 'vendor', 'SHETTY', 'AVINSHETTY1307@GMAIL.COM', '9620363160', '$2y$10$O0EWHjgar9qbIwzn8gByM.4GxLwwexVaoCZ.29hBmZAkmudkqkU0i', '0', '2022-04-07 09:18:45', NULL, NULL),
(3, 'vendor', 'SHETTY', 'BANGALOREBIRIYANI@GMAIL.COM', '9740675321', '$2y$10$X.r/NIo9x2aNl1vC/Rrh5OioaBUO0G52xPfBG3FKXZUXreAEuDkma', '0', '2022-04-07 09:21:56', NULL, NULL),
(4, 'vendor', 'GANESH', 'PARAMPARA@GMAIL.COM', '9008995720', '$2y$10$uyj0sbkVIn2GWzhYvF55OuTVRXIAK5U8Y6fDIv3VQy1xPaZgGf/bC', '0', '2022-04-07 10:18:33', NULL, NULL),
(5, 'vendor', 'SHETTY', 'A1AVINSHETTY@GMAIL.COM', '9886002046', '$2y$10$4TyP5u/ja14QLPG8autKI.HQbntLOlFPy5vV1GL.Av653wJeOmEf6', '0', '2022-04-07 11:20:48', NULL, NULL),
(6, 'vendor', 'SHETTY', 'BANGALORE12345@GMAIL.COM', '9632121703', '$2y$10$KueOIShUK9SUjvS2SK6TR.Hrs0cCxScXSk.5rFHX/HFQnM8sxJIDu', '0', '2022-04-07 11:48:21', NULL, NULL),
(7, 'vendor', 'AFL ', 'AYODHYAFOODLINE@GMAIL.COM', '8762687767', '$2y$10$LOdnDC0bv3lHVk4h/2s9g.OaE5yaqkgXipSqV.ar8CMqTMab1SOIW', '0', '2022-04-07 11:48:58', NULL, NULL),
(8, 'vendor', 'SHETTY', 'BIRIYANIHOUSEYESHWATHPUR@GMAIL.COM', '9740675322', '$2y$10$I5YaQ9.msbYzFyXez21EVeRHifRO6gbOUZMfdxtuMVkzqU6oCPPPK', '0', '2022-04-08 10:49:36', NULL, NULL),
(9, 'vendor', 'SHETTY', 'BIRIYANIHOUSEBANGALORE@GMAIL.COM', '9740675123', '$2y$10$Qd/jHC5/2VexVj7LO9VZBOsF9CVGS1XqU7QutwChczzviSMQ/HeWK', '0', '2022-04-08 11:02:21', NULL, NULL),
(10, 'user', 'avin', 'avin@gmail.com', '9740676672', '$2y$10$c6h4cxsxoKiJ6SAdXKZ2TO/dK9kaiyE5.UOMrLHwn9eiLxYLTf39e', '0', '2022-04-08 11:25:19', NULL, NULL),
(11, 'vendor', 'Test', 'test@test.com', 'test', '$2y$10$Qefr4gHAvlpxN3ztCSL5k.IRlIxaCVNpLSPj/0P2pYSD6bD60VuHq', '0', '2022-04-08 11:41:08', NULL, NULL),
(12, 'user', 'Ganeeh', 'gs6080661@gmail.com', '9886002045', '$2y$10$Vgvu3qDiZBokHH7KHZcac.R7a/IHRsheA4enRsVJZWa7DY/TN0rTm', '0', '2022-04-08 13:15:26', NULL, NULL),
(13, 'user', 'Shanaz', 'shanazshaikh9513@gmail.com', '9742521596', '$2y$10$b7omuB3ipBxndGU8YAjc7OEUWaJtnh8qlIh5HFY/zdWQxLB2DHyO.', '0', '2022-04-08 13:27:39', NULL, NULL),
(14, 'vendor', 'avin', 'superwiser@parampara.com', '1234567890', '$2y$10$mWQb6GH3NU6ESvrBT8saiOvtYt4T0hVTc9B/BUYzFWrQ0RXlgkDBK', '0', '2022-04-18 12:10:33', 'supervisor', 4),
(15, 'vendor', 'avin', 'casher@parampara.com', '0987654321', '$2y$10$T4TlblF3qESRoMN5l1DAKugdiMOnNRUA6NgLdPRMNupedSw4bHvhO', '0', '2022-04-18 12:11:48', 'cashier', 4),
(16, 'vendor', 'avin', 'manager@parampara.com', '5432167890', '$2y$10$QIc1rsqiSkh0M0N1CxJRculxJ5vS7GlC4w0vGUDDrK1LajIo9FVyO', '0', '2022-04-18 12:12:39', 'manager', 4),
(17, 'vendor', 'NAGARAJ SHETTY', 'swathigrand@gmail.com', '9600112233', '$2y$10$/L3tb.R5UhXpzzw28rLZyePhvs8ADAj7sEjpNNMd4r1L8k4V6Upou', '0', '2022-04-19 14:30:39', NULL, NULL),
(18, 'vendor', 'GOPAL NAIK', 'hotelkadamba@gmail.com', '9876543210', '$2y$10$j.19OfDQF50CrZw5za4XX.NxPy6VoxvcPfqhFvVNkhFzvQfrC7tIS', '0', '2022-04-19 14:40:13', NULL, NULL),
(19, 'vendor', 'zxxdd', 'sdsds@swe.com', '345345343434', '$2y$10$K85WzIiXEBnxq2jVJZ6DHOuhLq2f98ahZ3ISsFT4G2n0CPcd5vpPa', '0', '2022-04-20 17:23:12', 'supervisor', 18),
(20, 'user', 'Bect', 'alexmixeev323@gmail.com', '89388326879', '$2y$10$lSc6XLu.Np0JbcwqlnLy..8m73uCkNzfFs548XZv5.FUM.Q/j2caG', '0', '2022-04-22 23:17:27', NULL, NULL),
(21, 'vendor', 'Demo', 'ts@gmail.com', '9876543212', '$2y$10$iLzDdx1RlzvsKCAy1lYEIu3vI86K23H1ooZxEv.c4RI0jRAWCpNP.', '0', '2022-04-25 14:38:36', NULL, NULL),
(22, 'vendor', 'demo 1', 'dem@gmail.com', '9876543213', '$2y$10$1mVI.Xm4.q.CW/EyTRJ4/OglVjUAuY1vyetF9OxakysdnY0xeENNa', '0', '2022-04-26 17:21:46', NULL, NULL),
(23, 'user', 'Darshan', 'darshan8mr@gmail.com', '9535135278', '$2y$10$vwJpdlfPT9inaXnZHN.JTe.PAjJXZrjg/Ta3Lpp.ZaEMoeYo.RVt.', '0', '2022-04-27 10:44:18', NULL, NULL),
(24, 'user', 'Webbirth', 'webbirthsm@gmail.com', '8217063541', '$2y$10$7P10Ti7k/R5iCvZy7FE.oO9vlPCVewYv23.6Xg3tdlneu/clePIOG', '0', '2022-04-27 10:46:16', NULL, NULL),
(25, 'user', 'Test3', 'test3@gmail.com', '8884464462', '$2y$10$GkE4eiAp2x7D.zc2XROXoOJGVr.3HEF1yFm1IWR2ga5li4Obqjc/m', '0', '2022-04-27 10:49:21', NULL, NULL),
(26, 'user', 'test5', 'test5@gmail.com', '99887898989080', '$2y$10$6DrxSlTiwqEQls20ws7jS.SCqB9CeWZv9X4Nv4xSvfsaRD/rfpVDS', '0', '2022-04-27 13:05:03', NULL, NULL),
(27, 'user', 'Chaitra', 'Test@gmail.com', '6362335321', '$2y$10$BDtUH9nJOdwCPVdxBz0KQO4THbYc7Bu/3SXhM0RytzkFOS6lXsJv.', '0', '2022-04-27 13:09:03', NULL, NULL),
(28, 'vendor', 'Staffone', 'Staff@gmail.com', '9876543211', '$2y$10$x9r0XL3j/Nwo99eIc48/6u5PdUhpCQ74oMgYwFBEm0hXFUlgpEHT.', '0', '2022-04-27 13:19:04', 'supervisor', 18),
(29, 'vendor', 'avin', 'dfghjhgfd@gmail.com', '678123987', '$2y$10$ohYOX8aKoZGKWzOanXqz/.sAl3PGkTo42avGhsrJAoh5Ct10eEVqO', '0', '2022-04-27 16:28:18', 'cashier', 4),
(30, 'vendor', 'test', 'emailtest@gmail.com', '546544646', '$2y$10$anAJgxuULn4816A6vBIhAerTtUDeVEHSpjRtgtuHdSV5qcypjjrY2', '0', '2022-04-27 16:31:14', 'supervisor', 18),
(34, 'user', 'Test3', 'test3@gmail.comew', '88844644623', '$2y$10$GkE4eiAp2x7D.zc2XROXoOJGVr.3HEF1yFm1IWR2ga5li4Obqjc/m', '0', '2022-04-27 10:49:21', NULL, NULL),
(35, 'user', 'test5', 'test5@gmail.com32', '998878989890802', '$2y$10$6DrxSlTiwqEQls20ws7jS.SCqB9CeWZv9X4Nv4xSvfsaRD/rfpVDS', '0', '2022-04-27 13:05:03', NULL, NULL),
(36, 'user', 'Chaitra', 'Test@gmail.com23', '636233532123\r\n', '$2y$10$BDtUH9nJOdwCPVdxBz0KQO4THbYc7Bu/3SXhM0RytzkFOS6lXsJv.', '0', '2022-04-27 13:09:03', NULL, NULL),
(37, 'user', 'lkjh', 'arun@hc.com', '9066669966', '$2y$10$JAj.3LUarsVByDf9Yv3j6uLY2R8Fu90clowtxqMjvb3qDyoVBV/1y', '0', '2022-04-28 10:51:31', NULL, NULL),
(38, 'user', 'mm', 'mm@mm', '90809', '$2y$10$XKh3Mzo4vDZfLTXbVFyZDOh9h6Qaurg2iwGylfyvSMkvLDtCGy5xa', '0', '2022-04-29 00:29:57', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
